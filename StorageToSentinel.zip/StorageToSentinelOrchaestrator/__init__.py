"""Netskope To Azure Storage Durable Orchaestrator."""

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from ..SharedCode import consts
from ..StorageToSentinel.remove_duplicates_in_azure_storage import RemoveDuplicatesInAzureStorage
from ..SharedCode.logger import applogger

STORAGE_TO_SENTINEL_ORCHAESTRATOR = "StorageToSentinelOrchaestrator"


def orchestrator_function(context: DurableOrchestrationContext):
    """Start the orchaestration of the StorageToSentinel activity function."""
    share_names = consts.SHARE_NAME
    share_name_after_duplication = []
    for share in share_names:
        try:
            remove_duplicates_obj = RemoveDuplicatesInAzureStorage(share)
            remove_duplicates_obj.driver_code()
            share_name_after_duplication.append(share)
        except Exception:
            applogger.error(
                "{}(method={}) : {} : Error occurred in deduplication or file share not available for share-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    STORAGE_TO_SENTINEL_ORCHAESTRATOR,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    share,
                )
            )
    if len(share_name_after_duplication) > 0:
        parallel_tasks = [context.call_activity("StorageToSentinel", share) for share in share_name_after_duplication]
        outputs = yield context.task_all(parallel_tasks)
        return str(outputs)
    else:
        applogger.warn(
            "{}(method={}) : {} : No logs found to send to Sentinel after executing deduplication.".format(
                consts.LOGS_STARTS_WITH,
                STORAGE_TO_SENTINEL_ORCHAESTRATOR,
                consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
            )
        )


main = Orchestrator.create(orchestrator_function)
