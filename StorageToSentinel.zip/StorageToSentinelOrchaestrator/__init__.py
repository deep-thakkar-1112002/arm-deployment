"""Netskope To Azure Storage Durable Orchaestrator."""

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from ..SharedCode import consts
from ..StorageToSentinel.remove_duplicates_in_azure_storage import RemoveDuplicatesInAzureStorage


def orchestrator_function(context: DurableOrchestrationContext):
    """Start the orchaestration of the StorageToSentinel activity function."""
    share_names = consts.SHARE_NAME
    for share in share_names:
        remove_duplicates_obj = RemoveDuplicatesInAzureStorage(share)
        remove_duplicates_obj.driver_code()
    parallel_tasks = [context.call_activity("StorageToSentinel", share) for share in share_names]
    outputs = yield context.task_all(parallel_tasks)
    return str(outputs)


main = Orchestrator.create(orchestrator_function)
