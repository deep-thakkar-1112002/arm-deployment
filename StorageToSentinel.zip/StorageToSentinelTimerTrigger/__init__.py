# This function an Time Trigger starter function for Durable Functions.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable activity function (default name is "Hello")
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt
"""Starts the function invocations at the given timer."""
import logging
import azure.functions as func
from azure.durable_functions import DurableOrchestrationClient


async def main(mytimer: func.TimerRequest, starter: str) -> None:
    """Start the durable orachaestration."""
    client = DurableOrchestrationClient(starter)
    instance_id = await client.start_new("StorageToSentinelOrchaestrator", None, None)

    logging.info(f"Started Azure Storage To Sentinel orchestration with ID = '{instance_id}'.")

    if mytimer.past_due:
        logging.info("The timer is past due!")
