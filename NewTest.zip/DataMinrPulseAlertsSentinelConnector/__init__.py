"""This __init__ file will be called once trigger is generated."""
import datetime
import time
from .dataminr import DataMinr
from .logger import applogger
from .consts import LOGS_STARTS_WITH
import azure.functions as func


def main(mytimer: func.TimerRequest) -> None:
    """Start the execution.

    Args:
        mytimer (func.TimerRequest): timer trigger request
    """
    applogger.info("{} Start processing".format(LOGS_STARTS_WITH))
    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    start = time.time()
    dataminr_client = DataMinr()
    dataminr_client.send_dataminer_alerts_to_sentinel()
    end = time.time()
    applogger.info(
        "{} :time taken for data ingestion is {} sec".format(
            LOGS_STARTS_WITH, int(end - start)
        )
    )
    applogger.info("{} execution completed.".format(LOGS_STARTS_WITH))
    if mytimer.past_due:
        applogger.info("The timer is past due!")

    applogger.info("Python timer trigger function ran at %s", utc_timestamp)
