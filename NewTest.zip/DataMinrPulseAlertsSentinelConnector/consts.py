"""This file contains all constants."""
import os

SOURCE_SEPARATOR = 'via '
BASE_URL = os.environ.get("BaseURL", "https://gateway.dataminr.com/")
ENDPOINTS = {
                "authentication": "auth/2/token",
                "get_lists": "account/2/get_lists",
                "get_alerts": "api/3/alerts",
                "get_related_alerts": "alerts/2/get_related"
            }
ALERT_VERSION = 14
LOGS_STARTS_WITH = "DataMinrPulseAlerts:"
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
MAPPING_TABLE_NAME = "{}_Mapping_RelatedAlerts"
KEYVAULT_CLIENTSECRET_KEY = "DataMinrPulse-clientSecret"
KEYVAULT_CLIENTID_KEY = "DataMinrPulse-clientId"
KEYVAULT_DMATOKEN_KEY = "DataMinrPulse-DmaToken"
KEYVAULT_REFRESHTOKEN_KEY = "DataMinrPulse-RefreshToken"
KEYVAULT_EXPIRETIME_KEY = "DataMinrPulse-Expire"
