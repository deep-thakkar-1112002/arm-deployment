"""This File contains custom Exception class for DataMinr."""


class DataMinrException(Exception):
    """Exception class to handle DataMinr exception."""

    def __init__(self, message):
        """Initialize custom DatMinrException with custom message."""
        super().__init__(message)
