"""Netskope To Azure Storage Durable Orchaestrator."""
import json

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from ..SharedCode import consts
from ..SharedCode.logger import applogger


def orchestrator_function(context: DurableOrchestrationContext):
    """Orchaestrator Function."""
    try:
        tasks = []
        alerts_list = consts.ALERTS_TYPE_INPUT
        events_list = consts.EVENTS_TYPE_INPUT
        alerts_json = []
        events_json = []
        for alert_type in alerts_list:
            alerts_json.append(
                json.dumps({"type_of_data": "alerts", "sub_type": alert_type})
            )
        for event_type in events_list:
            events_json.append(
                json.dumps({"type_of_data": "events", "sub_type": event_type})
            )
        applogger.info("The alerts_json is {}".format(alerts_json))
        applogger.info("The events_json is {}".format(events_json))
        for alert_json in alerts_json:
            tasks.append(context.call_activity("NetskopeToAzureStorage", alert_json))
        for event_json in events_json:
            tasks.append(context.call_activity("NetskopeToAzureStorage", event_json))
        yield context.task_all(tasks)
    except Exception as error:
        applogger.error("The error is {}".format(error))


main = Orchestrator.create(orchestrator_function)
