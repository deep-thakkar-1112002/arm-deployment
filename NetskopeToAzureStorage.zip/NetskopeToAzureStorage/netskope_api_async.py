"""Make API call and handle exceptions."""
import asyncio
import inspect
from random import randrange
import time
import aiohttp
from ..SharedCode import consts
from ..SharedCode.netskope_exception import NetskopeException
from ..SharedCode.logger import applogger
from aiohttp.client_exceptions import ServerDisconnectedError
from ..SharedCode.state_manager import StateManager


class NetskopeAPIAsync:
    """Class to handle Netskope asynchronous api calls and exception handling."""

    def __init__(self, type_of_data, sub_type, function_start_time) -> None:
        """Initialize NetskopeAPIAsync class.

        Args:
            type_of_data (str): The type of Netskope Data to fetch.(alerts/events)
            sub_type (str): The subtype of the data to fetch.
        """
        self.hostname = consts.NETSKOPE_HOSTNAME
        self.type_of_data = type_of_data
        self.sub_type = sub_type
        self.nskp_data_type_for_logging = self.type_of_data + "_" + self.sub_type
        self.function_start_time = function_start_time
        self.retry_sleep_time_409 = 30

    def url_builder(self, iterator_name, operation) -> str:
        """Build the URL and return the built url.

        Returns:
            str: Generated url for http request
        """
        url = consts.URL[self.type_of_data].format(
            hostname=self.hostname,
            sub_type=self.sub_type,
            iterator_name=iterator_name,
            operation=operation,
        )
        return url

    async def handle_exponential_sleep_time(self, iterator_name):
        """Handle the exponential sleep time for Netskope Api.

        Args:
            iterator_name (str): iterator name

        Raises:
            NetskopeException: Custom Exception

        Returns:
            int: the value for retry backoff
        """
        __method_name = inspect.currentframe().f_code.co_name
        state_manager_obj_for_sleep_time = StateManager(consts.CONNECTION_STRING, "{}_sleep_time".format(iterator_name), consts.SHARE_NAME)
        raw_data = state_manager_obj_for_sleep_time.get(consts.NETKOPE_TO_AZURE_STORAGE)
        remaining_execution_time = consts.DATA_COLLECTION_TIMEOUT - (int(time.time()) - self.function_start_time)
        if raw_data is None:
            applogger.info(
                "{}(method={}) : {} ({}): No sleep file found for iter-{} indicating first time error-409.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    iterator_name
                )
            )
            if remaining_execution_time > 5:
                applogger.info(
                    "{}(method={}) : {} ({}): Sleeping for 30 seconds as time is available.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                    )
                )
                state_manager_obj_for_sleep_time.post("1,0")
                await asyncio.sleep(30)
                return 1
            applogger.info(
                "{}(method={}) : {} ({}): Less time is available, hence raising exception.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        retry_backoff, remaining_seconds_from_prev_run = raw_data.split(',')
        if remaining_seconds_from_prev_run == '0':
            sleep_seconds = (int(retry_backoff) * 2) * self.retry_sleep_time_409
            applogger.info(
                "{}(method={}) : {} ({}): Sleeping for {} seconds as time is available.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    sleep_seconds
                )
            )            
            retry_backoff = int(retry_backoff) * 2
            if sleep_seconds < remaining_execution_time:
                applogger.info(
                    "{}(method={}) : {} ({}): Sleeping for {} seconds as time is available.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        sleep_seconds
                    )
                )
                state_manager_obj_for_sleep_time.post("{},0".format(retry_backoff))
                await asyncio.sleep(sleep_seconds)
                return retry_backoff
            available_sleep_time = sleep_seconds - remaining_execution_time
            sleep_time_remaining = sleep_seconds - available_sleep_time
            state_manager_obj_for_sleep_time.post("{},{}".format(retry_backoff, sleep_time_remaining))
            applogger.info(
                "{}(method={}) : {} ({}): Remaining time is less than the required sleep time, Sleeping for {} seconds.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    available_sleep_time
                )
            )
            await asyncio.sleep(available_sleep_time)
            raise NetskopeException()
        sleep_seconds = int(remaining_seconds_from_prev_run)
        if sleep_seconds < remaining_execution_time:
            state_manager_obj_for_sleep_time.post("{},0".format(retry_backoff))
            applogger.info(
                "{}(method={}) : {} ({}): Sleeping for {} seconds to resolve old sleep time.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    sleep_seconds
                )
            )
            await asyncio.sleep(sleep_seconds)
            return int(retry_backoff)
        available_sleep_time = sleep_seconds - remaining_execution_time
        sleep_time_remaining = sleep_seconds - available_sleep_time
        state_manager_obj_for_sleep_time.post("{},{}".format(retry_backoff, sleep_time_remaining))
        applogger.info(
            "{}(method={}) : {} ({}): Remaining time is less than the required sleep time, Sleeping for {} seconds.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
                self.nskp_data_type_for_logging,
                available_sleep_time
            )
        )
        await asyncio.sleep(available_sleep_time)
        raise NetskopeException()


    async def aio_http_handler(self, url, session: aiohttp.ClientSession, iterator_name, server_disconnect_retry=0):
        """Make http request and handle the api call errors.

        Args:
            url (str): The url to perform the http request.
            session (aiohttp.ClientSession): The session object used to perform api calls.

        Raises:
            NetskopeException: Netskope Custom Exception

        Returns:
            dict: Response from the api
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            # check if exponential backoff is still in place.
            state_manager_obj_for_sleep_time = StateManager(consts.CONNECTION_STRING, "{}_sleep_time".format(iterator_name), consts.SHARE_NAME)
            raw_data = state_manager_obj_for_sleep_time.get(consts.NETKOPE_TO_AZURE_STORAGE)
            retry_backoff_multiplier = 0
            if raw_data is not None:
                applogger.debug(
                    "{}(method={}) : {} ({}): Found sleep time file for iterator-{}.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        iterator_name,
                    )
                )
                retry_backoff, remaining_seconds_from_prev_run = raw_data.split(',')
                if remaining_seconds_from_prev_run == "0":
                    applogger.debug(
                        "{}(method={}) : {} ({}): Remaining sleep from previous run is 0, Updating backoff-{}.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                            retry_backoff,
                        )
                    )
                    retry_backoff_multiplier = int(retry_backoff)
                retry_backoff_multiplier = await self.handle_exponential_sleep_time(iterator_name)
            retry_count_429 = 0
            retry_count_409 = 6
            retry_count_500 = 0
            
            # Implemented retry mechanism for the status codes 409, 429 and 500.
            # Retry count for 429 is higher due to higher frequency seen in tests.
            while retry_count_429 <= 6 and retry_backoff_multiplier < 2 ** retry_count_409 and retry_count_500 <= 6:
                applogger.debug(
                    "{}(method={}) : {} ({}): Initiating the get request.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                    )
                )
                response = await session.get(url=url)
                applogger.info(
                    "{}(method={}) : {} ({}): The API call response status code is {}.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        response.status,
                    )
                )
                if response.status == 200:
                    applogger.info(
                        "{}(method={}) : {} ({}): Successfully fetched netskope data.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                        )
                    )
                    json_response = await response.json()
                    return json_response
                elif response.status == 403:
                    applogger.error(
                        "{}(method={}) : {} ({}): Status code 403 token issue."
                        "Check the API V2 token is associated to the valid endpoint and its not expired.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                        )
                    )
                    raise NetskopeException()
                elif response.status == 409:
                    applogger.error(
                        "{}(method={}) : {} ({}): Status code 409."
                        "Concurrency conflict and the request cannot be processed currently. Sleeping...".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                        )
                    )
                    retry_backoff_multiplier = await self.handle_exponential_sleep_time(iterator_name)
                elif response.status == 429:
                    retry_after = response.headers.get("RateLimit-Reset")
                    applogger.error(
                        "{}(method={}) : {} ({}): Status code 429."
                        "Too many request for the same tenant for the same endpoint. Retrying after {} seconds.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                            retry_after,
                        )
                    )
                    await asyncio.sleep(float(retry_after))
                    retry_count_429 += 1
                elif response.status >= 500 and response.status < 600:
                    applogger.error(
                        "{}(method={}) : {} ({}): Status code {}. Netskope is having a temporary server issue."
                        "Retrying after 5 seconds.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                            response.status,
                        )
                    )
                    await asyncio.sleep(randrange(5, 10))
                    retry_count_500 += 1

            applogger.error(
                "{}(method={}) : {} ({}): Max retries exceeded.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        # Catching Server Disconnected Error which occurs when the amount of concurrent requests increases.
        # Hence Retrying with random sleep timer.
        except ServerDisconnectedError as server_error:
            if server_disconnect_retry < 3:
                retry_time = randrange(2, 10)
                applogger.error(
                    "{}(method={}) : {} ({}): Server Disconnect error. Error-{}. Retrying after - {} seconds.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        server_error,
                        retry_time,
                    )
                )
                server_disconnect_retry += 1
                await asyncio.sleep(retry_time)
                json_response = await self.aio_http_handler(url, session, server_disconnect_retry)
                return json_response
            applogger.error(
                "{}(method={}) : {} ({}): Max retries exceeded for server disconnect error.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()

        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}): Error while fetching data.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}): Error while fetching data, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()
