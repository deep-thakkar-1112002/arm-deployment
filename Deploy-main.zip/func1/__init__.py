import logging
import os
import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    func_app_name=os.environ.get('WEBSITE_CONTENTSHARE')
    func_app_name=func_app_name[0:-6]
    link=f'https://{func_app_name}.azurewebsites.net/api/downloadhtmlpoc?url='
    url_to_hit='https://alerteventmonitoringdeep.blob.core.windows.net/dummy-container-blob-test/test_deep.html'
    final_url=link+url_to_hit
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             f"This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response. link_to_hit={final_url}",
             status_code=200
        )
