import logging
import requests
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    url = req.params.get('url')
    if not url:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            url = req_body.get('url')

    if url:
        response=requests.get(url=url)
        filename="report.html"
        # mimetype=mimetypes.guess_type(response.content)
        # return func.HttpResponse(response.content,mimetype='text/html',headers={'Content-Disposition': 'inline', 'filename':'test.html'})

        return func.HttpResponse(response.content,mimetype='text/html',headers={'Content-Disposition': f'attachment; filename="{filename}"'})
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
